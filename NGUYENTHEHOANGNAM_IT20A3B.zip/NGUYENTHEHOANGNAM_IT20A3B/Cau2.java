package NGUYENTHEHOANGNAM_IT20A3B;

import java.util.Scanner;

public class Cau2 {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            int a, b, c;
            a = 5;
            b = 6;
            c = 7;

            if (a >= b && a >= c) {
                System.out.println(a);
            }
            if (b >= a && b >= c) {
                System.out.println(b);
            }
            if (c >= a && c >= b) {
                System.out.println(c);
            }

        }
    }

